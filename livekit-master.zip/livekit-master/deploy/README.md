# LiveKit Server Deployment

Deployment Guides:

- [Deploy to a VM](https://docs.livekit.io/deploy/vm)
- [Deploy to Kubernetes](https://docs.livekit.io/deploy/kubernetes)

Also included are Grafana charts for metrics gathered in Prometheus.
